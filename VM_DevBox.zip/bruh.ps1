# PowerShell script to install various software

# Set execution policy to bypass for the current process
Set-ExecutionPolicy Bypass -Scope Process -Force;

# Install Chocolatey
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Install Git
choco install git -y

# Install Node.js LTS
choco install nodejs-lts -y

# Install Visual Studio Code
choco install vscode -y

# Install Office 365 Business
choco install office365business -y

# lfol Install Java Runtime
choco install javaruntime -y


